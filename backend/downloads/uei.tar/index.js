const express = require('express');
const bodyParser = require('body-parser');
const _ = require('lodash');
const app = express();
const app2 = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app2.use(bodyParser.json());
app2.use(bodyParser.urlencoded({extended: true}));

let message;

app.get('/ready', (req, res) => {
    console.log('switch is ready');
    res.status(200).send();
});

app2.post('/expectMessage', async (req, res) => {
    console.log('got message from sky path');
    if (_.has(req, 'body.message.skyPathMessageId')) {
        console.log('got valid message from sky path');
        message = req.body.message;
        res.status(200);
    } else {
        console.log('got invalid message (without sky path message id) from sky path');
        res.status(400);
    }
    res.send();
});

app.post('/command/validateMessage', async (req, res) => {
    if (message && message.msgType === req.body.type) {
        console.log('validation completed successfully');
        console.log(`the message - ${JSON.stringify(message)}`);
        res.status(200);
    } else {
        console.log('got invalid message from sky path');
        console.log(`the message - ${JSON.stringify(message)}`);
        console.log(`expected type - ${req.body.type}`);
        res.status(400);
    }
    res.send();
});

app.listen(3000, () => {
    console.log('started to listen at 3000')
});

app2.listen(9002, () => {
    console.log('started to listen at 9002')
});