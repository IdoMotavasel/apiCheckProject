import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import _ from 'lodash';

const app = express();
const app2 = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app2.use(bodyParser.json());
app2.use(bodyParser.urlencoded({ extended: true }));

interface SkyPathMessage {
    skyPathMessageId: string;
    [key: string]: any;
}

interface ReceivedMessage {
    msgType: string;
    [key: string]: any;
}

let message: ReceivedMessage | null = null;

app.get('/ready', (req: Request, res: Response) => {
    console.log('Switch is ready');
    res.status(200).send();
});

app2.post('/expectMessage', (req: Request, res: Response) => {
    console.log('Received message from sky path');

    if (_.has(req.body, 'message.skyPathMessageId')) {
        console.log('Valid message from sky path');
        message = req.body.message as ReceivedMessage;
        res.status(200).send();
    } else {
        console.log('Invalid message (no skyPathMessageId) from sky path');
        res.status(400).send();
    }
});

app.post('/command/validateMessage', (req: Request, res: Response) => {
    const { type } = req.body;

    if (message && message.msgType === type) {
        console.log('Validation successful');
        console.log(`Message: ${JSON.stringify(message)}`);
        res.status(200).send();
    } else {
        console.log('Invalid message validation');
        console.log(`Received message: ${JSON.stringify(message)}`);
        console.log(`Expected type: ${type}`);
        res.status(400).send();
    }
});

const PORT1 = 4000;
const PORT2 = 9002;

app.listen(PORT1, () => {
    console.log(`Server listening on port ${PORT1}`);
});

app2.listen(PORT2, () => {
    console.log(`Server listening on port ${PORT2}`);
});
